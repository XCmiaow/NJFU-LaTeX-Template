# 《塑料的奥秘》课程论文——选题10

题目：**塑料添加剂的释放机制与多尺度健康风险**。

正文为文献综述和可复现的传质/暴露情景分析，包含20条参考文献（2条中文教材、18条英文论文/教材），8组并排图（16子图）和6张LaTeX三线表。原始研究、模型情景和机制示意均已在正文/图注区分。不得把情景模型改写为作者开展的实验。

## 文件

- `main.tex`：通常编译入口。
- `main-strict.tex`：原版字体检查入口，缺少字体就明确停止。
- `course-format.sty`：课程专用格式。
- `paper-info.tex`：封面个人信息；已使用方绪杰、2410407105、化学工程学院、林产化工，教师陈丽媛。
- `cover.tex`：现有个人封面的排版；将你自己的封面PDF命名为`custom-cover.pdf`放在项目根目录即可优先替换。
- `sections/`：正文。
- `references.bib`：完整参考文献与DOI；印刷版采用GB/T 7714数字顺序制。
- `scripts/make_figures.py`：重绘全部图。
- `data/`：公式计算和文献实测数据；`sources/SOURCE-LEDGER.md`说明核验范围。

## 与附件的对应

A4；页边距按原DOCX提取：左右3.175cm、上下2.54cm。正文12bp（小四），固定22bp行距，首行2字符，段前段后0，两端对齐。论文题目与章标题16bp（三号），二级标题15bp（小三）不加粗，三级标题14bp（四号）。参考文献标题黑体三号，条目小四、悬挂缩进。摘要、3—5关键词、前言、主体、结论、参考文献按附件顺序排列，没有额外目录或英文摘要。正文长度按用户提出的约20页执行，不通过放大字体/行距凑页数。

附件未规定图表字体，表格10.5bp、图注和来源注9—11bp，以兼顾三线表与并排图的密度。所有正文段落继续保持小四、22bp。

**原版字体限制：**当前云环境没有Microsoft宋体和Times New Roman，预览采用Fandol宋体及TeX Gyre Termes。它们不是原版字体，不能将当前PDF称为字体完全一致的最终提交版。模板会在装有SimSun和Times New Roman的机器上自动使用原版字体。也可把有权使用的`simsun.ttc`以及`times.ttf`、`timesbd.ttf`、`timesi.ttf`、`timesbi.ttf`放在`fonts/`目录再编译。项目不包含这些商业字体。

## 编译

在已设置的云环境中：

```bash
bash scripts/build.sh
```

在本地或Overleaf（TeX Live 2024+，XeLaTeX，BibTeX，latexmk，ctex，gbt7714）中：

```bash
latexmk -xelatex -interaction=nonstopmode -halt-on-error main.tex
# 原版字体都已就绪时：
latexmk -xelatex -interaction=nonstopmode -halt-on-error main-strict.tex
```

Overleaf无需安装Python即可编译，项目包含已生成的矢量PDF图；但默认Overleaf也未必有Windows原版字体，应依法提供字体并选择严格入口。严格入口的输出不会把缺失字体默默替换掉。

Python重绘需要numpy、scipy和matplotlib：

```bash
python3 scripts/make_figures.py
```

图中英文是SCI期刊常见的独立标注方式；中文图题及完整来源说明在LaTeX中。核心曲线是确定性计算，无随机生成的“实验样本”。

## 打印

封面单面打印并单独放置；正文PDF从第2个物理页起双面打印。PDF采用相同左右页边距，正文从1开始编号。若直接双面打印整份含封面PDF，应在打印机设置中将封面单独处理，避免正文第一页出现在封面背面。

## 科学核查

17篇期刊论文的DOI元数据已在线核对；取得并核查了4篇开放全文中的相关内容。两本中文教材的主编顺序、版次、ISBN和首次出版年已经通过出版社目录核对；三本教材均未取得原书全文。文献数据图分别注明历史统计/动物资料，模型参数明确为假设。学生提交前应阅读课程要求和关键原文，并核对封面日期。

## 本次文风修订

依据用户指定的`cumcm-team-style`中有关自然表达、证据链、变量定义和图表说明的通用细节修改；保留课程格式，未引入赛事结构或提交规定。详见`sources/STYLE-REVISION.md`。
