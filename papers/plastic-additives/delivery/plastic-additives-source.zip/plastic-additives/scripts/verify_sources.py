"""Read-only online metadata/full-text checks. Preserve raw results and access errors.
This does not invent missing records or claim metadata equals full-text verification.
"""
from pathlib import Path
import re,json,time
from urllib.request import Request,urlopen
from urllib.parse import quote,urlencode
from concurrent.futures import ThreadPoolExecutor
ROOT=Path(__file__).resolve().parents[1];OUT=ROOT/'sources';OUT.mkdir(exist_ok=True)
text=(ROOT/'references.bib').read_text();dois=re.findall(r'doi=\{([^}]+)\}',text)

def fetch(doi):
 key=doi.replace('/','_');report={'doi':doi,'metadata_verified':False,'full_text_verified':False}
 try:
  url='https://api.crossref.org/works/'+quote(doi,safe='')
  with urlopen(Request(url,headers={'User-Agent':'CoursePaperSourceCheck/1.0'}),timeout=25) as r:raw=r.read()
  (OUT/f'{key}.crossref.json').write_bytes(raw);m=json.loads(raw)['message'];report.update(metadata_verified=True,title=m.get('title'),year=m.get('published',{}),authors=m.get('author'),pages=m.get('page'))
 except Exception as e:report['metadata_error']=str(e)
 try:
  url='https://www.ebi.ac.uk/europepmc/webservices/rest/search?'+urlencode({'query':'DOI:'+doi,'format':'json','resultType':'core'})
  with urlopen(Request(url,headers={'User-Agent':'CoursePaperSourceCheck/1.0'}),timeout=25) as r:raw=r.read()
  (OUT/f'{key}.epmc.json').write_bytes(raw)
  for item in json.loads(raw).get('resultList',{}).get('result',[]):
   if item.get('pmcid') and item.get('isOpenAccess')=='Y':
    url='https://www.ebi.ac.uk/europepmc/webservices/rest/'+item['pmcid']+'/fullTextXML'
    with urlopen(Request(url,headers={'User-Agent':'CoursePaperSourceCheck/1.0'}),timeout=25) as r:xml=r.read()
    (OUT/f'{key}.fulltext.xml').write_bytes(xml);report.update(full_text_verified=True,pmcid=item['pmcid']);break
 except Exception as e:report['fulltext_access_error']=str(e)
 return report
with ThreadPoolExecutor(max_workers=4) as pool:reports=list(pool.map(fetch,dois))
(OUT/'verification-status.json').write_text(json.dumps(reports,ensure_ascii=False,indent=2))
print(f'DOI metadata retrieved: {sum(r["metadata_verified"] for r in reports)}/{len(reports)}')
print(f'Open full texts retrieved: {sum(r["full_text_verified"] for r in reports)}/{len(reports)}')
for r in reports:
 if r.get('metadata_error'):print(r['doi'],r['metadata_error'])
