#!/usr/bin/env bash
set -euo pipefail
project_dir=$(cd -- "$(dirname -- "${BASH_SOURCE[0]}")/.." && pwd)
if [ -f /workspace/onboarding-njfu/activate.sh ]; then
  . /workspace/onboarding-njfu/activate.sh
fi
cd "$project_dir"
build_dir=${PAPER_BUILD_DIR:-/workspace/onboarding-njfu/build/plastic-additives}
entry=${PAPER_ENTRY:-main.tex}
mkdir -p "$build_dir"
latexmk -xelatex -interaction=nonstopmode -halt-on-error -outdir="$build_dir" "$entry"
pdfinfo "$build_dir/${entry%.tex}.pdf"
