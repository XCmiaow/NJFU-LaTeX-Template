"""Rebuild paper figures 7 and 8 without touching unrelated figures.

Figure 7 is an illustrative calculation, not an experimental risk estimate.
Figure 8 reads complete Geyer et al. (2017) supplementary Tables S3 and S5.
Run: python3 scripts/redraw_figures_7_8.py
"""
from pathlib import Path
import csv

import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
import numpy as np

ROOT = Path(__file__).resolve().parents[1]
BLUE, ORANGE, OLIVE, GRAY = "#17618A", "#C36A2D", "#6D7945", "#555B62"
STYLE = {
    "font.family": "DejaVu Sans", "font.size": 9,
    "axes.labelsize": 9, "axes.titlesize": 10,
    "xtick.labelsize": 8.5, "ytick.labelsize": 8.5,
    "axes.spines.top": False, "axes.spines.right": False,
    "axes.linewidth": .7, "lines.linewidth": 1.6,
    "pdf.fonttype": 42, "ps.fonttype": 42,
    "savefig.dpi": 350, "figure.facecolor": "white",
    "axes.facecolor": "white", "axes.grid": False,
}


def save(fig, name):
    for suffix in ("pdf", "png"):
        fig.savefig(ROOT / "figures" / f"{name}.{suffix}",
                    bbox_inches="tight", pad_inches=.04)
    plt.close(fig)


def tidy(ax, grid_axis):
    ax.tick_params(direction="out", length=3, width=.7)
    ax.set_axisbelow(True)
    ax.grid(axis=grid_axis, color="#E5E8EB", linewidth=.6)


def draw_mixture_recycling():
    with plt.rc_context(STYLE):
        fig = plt.figure(figsize=(6.35, 2.95))
        # Fixed panel bounds reserve space for the second y label and end labels.
        left = fig.add_axes([.09, .19, .345, .65])
        right = fig.add_axes([.605, .19, .37, .65])
        left.set_title("(a) Concentration addition", loc="left", pad=12)
        right.set_title("(b) Carry-over across loops", loc="left", pad=12)
        tidy(left, "y")
        tidy(right, "y")

        # The waterfall makes the addition explicit; the final gray bar is HI.
        values = np.array([.15, .20, .25, .60])
        bottoms = np.array([0, .15, .35, 0])
        left.bar(np.arange(4), values, bottom=bottoms, width=.59,
                 color=[BLUE, ORANGE, OLIVE, GRAY], zorder=3)
        for i, top in enumerate([.15, .35, .60]):
            left.plot([i + .295, i + .705], [top, top],
                      color="#9BA2A8", linewidth=.8)
        for i, (v, bottom) in enumerate(zip(values, bottoms)):
            label = f"+{v:.2f}" if i in (1, 2) else f"{v:.2f}"
            left.text(i, bottom + v + .035, label, ha="center", fontsize=8.5)
        left.axhline(1, color=GRAY, linestyle=(0, (4, 3)), linewidth=.9)
        left.text(3.42, 1.035, "Screening reference = 1", ha="right", fontsize=8)
        left.set_xticks(range(4), [r"HQ$_1$", r"HQ$_2$", r"HQ$_3$", "HI"])
        left.set_ylabel("Screening ratio")
        left.set_ylim(0, 1.16)
        left.set_xlim(-.55, 3.55)
        left.set_yticks(np.arange(0, 1.01, .2))

        loops = np.arange(11)
        for r, color, marker, line in [(.3, BLUE, "o", "-"),
                                       (.7, ORANGE, "s", "--"),
                                       (.9, OLIVE, "^", "-.")]:
            q = r * .90
            cn = .10 * (1 - q ** loops) / (1 - q)
            right.plot(loops, cn, color=color, marker=marker, ms=3.4,
                       linestyle=line, linewidth=1.5, zorder=3)
            right.annotate(f"r = {r:.1f}", (10, cn[-1]), xytext=(5, 0),
                           textcoords="offset points", va="center",
                           color=color, fontsize=8.5)
        right.set_xlabel("Recycling loop, n")
        right.set_ylabel(r"$C_n$ (normalized)", labelpad=7)
        right.set_xlim(-.25, 12.2)
        right.set_ylim(-.015, .51)
        right.set_xticks(np.arange(0, 11, 2))
        right.set_yticks(np.arange(0, .51, .1))
        # Parameter notes sit below both panels, away from curves and labels.
        fig.text(.54, .025, r"$s = 0.90$; $a = 0.10$; $C_0 = 0$",
                 fontsize=8.5, ha="center", color=GRAY)
        save(fig, "07-mixture-recycling")


def draw_lifecycle():
    with (ROOT / "data/geyer2017_table_S3.csv").open() as f:
        additives = list(csv.DictReader(f))
    with (ROOT / "data/geyer2017_table_S5.csv").open() as f:
        sectors = list(csv.DictReader(f))
    additives.sort(key=lambda row: -int(row["share_percent"]))
    sectors.sort(key=lambda row: -int(row["primary_production_Mt"]))
    # Preserve the source totals; no interpolation or synthetic observations.
    assert sum(int(row["share_percent"]) for row in additives) == 100
    assert sum(int(row["primary_production_Mt"]) for row in sectors) == 407
    assert sum(int(row["primary_waste_Mt"]) for row in sectors) == 302

    with plt.rc_context(STYLE):
        fig = plt.figure(figsize=(6.35, 4.15))
        left = fig.add_axes([.205, .145, .245, .66])
        right = fig.add_axes([.695, .145, .285, .66])
        for ax in (left, right):
            tidy(ax, "x")
            ax.spines["left"].set_visible(False)
            ax.tick_params(axis="y", length=0, pad=5)
        left.set_title("(a) Additive composition", loc="left", y=1.18, pad=0)
        right.set_title("(b) Sector material flows", loc="left", y=1.18, pad=0)
        left.text(0, 1.09, "2000–2014 data synthesis", transform=left.transAxes,
                  fontsize=8.3, color=GRAY)
        right.text(0, 1.09, "2015 primary plastics", transform=right.transAxes,
                   fontsize=8.3, color=GRAY)
        names = [row["additive_type"] for row in additives]
        shares = [int(row["share_percent"]) for row in additives]
        colors = [{"Plasticizers": BLUE, "Fillers": OLIVE,
                   "Flame retardants": ORANGE}.get(name, "#AEB6BF") for name in names]
        left.barh(np.arange(10), shares, color=colors, height=.62, zorder=3)
        left.set_yticks(range(10), names)
        left.set_ylim(9.7, -.7)
        left.set_xlim(0, 41)
        left.set_xticks([0, 10, 20, 30, 40])
        left.set_xlabel("Share of all additives (%)", labelpad=8)
        for y, share in enumerate(shares):
            left.text(share + .8, y, f"{share}%", va="center", fontsize=8.5)

        labels = {
            "Building and Construction": "Construction",
            "Consumer and Institutional Products": "Consumer /\ninstitutional",
            "Electrical/Electronic": "Electrical /\nelectronic",
            "Industrial Machinery": "Industrial\nmachinery",
        }
        yy = np.arange(len(sectors))
        production = [int(row["primary_production_Mt"]) for row in sectors]
        waste = [int(row["primary_waste_Mt"]) for row in sectors]
        right.hlines(yy, waste, production, color="#B8C1C8", linewidth=1.5)
        right.scatter(production, yy, color=BLUE, s=23, zorder=4, label="Production")
        right.scatter(waste, yy, color=ORANGE, marker="D", s=20, zorder=4, label="Waste")
        for y, p, w in zip(yy, production, waste):
            right.annotate(str(p), (p, y), xytext=(3, 4),
                           textcoords="offset points", color=BLUE,
                           fontsize=8.2, ha="left")
            right.annotate(str(w), (w, y), xytext=(3, -8),
                           textcoords="offset points", color=ORANGE,
                           fontsize=8.2, ha="left")
        right.set_yticks(yy, [labels.get(row["sector"], row["sector"]) for row in sectors])
        right.set_ylim(7.8, -.8)
        right.set_xlim(-4, 165)
        right.set_xticks([0, 50, 100, 150])
        right.set_xlabel("Annual mass (Mt)", labelpad=8)
        right.legend(loc="lower left", bbox_to_anchor=(-.04, .995),
                     frameon=False, ncol=2, fontsize=8.1,
                     handletextpad=.3, columnspacing=.7, borderaxespad=0,
                     handlelength=.8)
        save(fig, "06-lifecycle")


if __name__ == "__main__":
    draw_mixture_recycling()
    draw_lifecycle()
    print("Updated paper figures 7 and 8 (PDF + 350 dpi PNG).")
