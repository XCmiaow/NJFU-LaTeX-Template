"""Reproducible paired figures. Empirical, computed, and schematic outputs are separated.
Run from the project root: python3 scripts/make_figures.py
No random data are generated. All model parameters are illustrative, not fitted.
"""
from pathlib import Path
import json,csv
import numpy as np
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from matplotlib.patches import FancyBboxPatch,FancyArrowPatch
from matplotlib.ticker import LogLocator,ScalarFormatter
from scipy.optimize import brentq

ROOT=Path(__file__).resolve().parents[1]
FIG=ROOT/'figures'; DATA=ROOT/'data';FIG.mkdir(exist_ok=True);DATA.mkdir(exist_ok=True)
plt.rcParams.update({'font.family':'DejaVu Sans','font.size':8.5,'axes.labelsize':9,'axes.titlesize':10,'legend.fontsize':7.2,'xtick.labelsize':8,'ytick.labelsize':8,'axes.spines.top':False,'axes.spines.right':False,'axes.linewidth':.7,'lines.linewidth':1.5,'pdf.fonttype':42,'ps.fonttype':42,'savefig.dpi':350,'figure.facecolor':'white','axes.facecolor':'white','axes.grid':False})
C={'blue':'#17618A','orange':'#C36A2D','olive':'#6D7945','purple':'#806396','gray':'#555B62'}
COL=list(C.values())

def pair(): return plt.subplots(1,2,figsize=(6.45,2.55),layout='constrained')
def panel(ax,label,title):
 ax.set_title(f'({label}) {title}',loc='left',pad=9,fontweight='normal');ax.tick_params(direction='out',length=3,width=.7)
def save(fig,name):
 fig.savefig(FIG/f'{name}.pdf',bbox_inches='tight');fig.savefig(FIG/f'{name}.png',bbox_inches='tight');plt.close(fig)
def rows(name,header,data):
 with (DATA/name).open('w',newline='') as f:
  w=csv.writer(f);w.writerow(header);w.writerows(data)
def released(Fo):
 """Exact two-face perfect-sink slab; L is half-thickness, Fo=D*t/L**2."""
 x=np.asarray(Fo,dtype=float);n=np.arange(400,dtype=float);odd=2*n+1
 z=1-8/np.pi**2*np.sum(np.exp(-x[...,None]*(odd*np.pi)**2/4)/odd**2,axis=-1)
 return np.where(x==0,0,np.clip(z,0,1))

# 1. Molecular composition: weights calculated from formulas, not chemical assays.
chem=[('DBP','C16H22O4',278.34),('DEHP','C24H38O4',390.56),('BPA','C15H16O2',228.29),('BPS','C12H10O4S',250.27),('TPHP','C18H15O4P',326.28),('TBBPA','C15H12Br4O2',543.87),('BDE-209','C12Br10O',959.17)]
fig,ax=pair();y=np.arange(len(chem));colors=[C['blue']]*2+[C['orange']]*2+[C['olive']]*3
ax[0].barh(y,[a[2] for a in chem],color=colors,height=.64)
ax[0].set_yticks(y,[a[0] for a in chem]);ax[0].invert_yaxis();ax[0].set_xlabel('Molar mass (g mol$^{-1}$)');ax[0].set_xlim(0,1150)
for i,a in enumerate(chem):ax[0].text(a[2]+12,i,f'{a[2]:.2f}',va='center',fontsize=7.7)
panel(ax[0],'a','Representative molecular sizes')
ax[1].axis('off');panel(ax[1],'b','Binding state controls availability')
texts=[('Plasticizer / additive FR','Physically mixed in polymer','Diffusion + partition + surface loss',C['blue']),('BPA in polycarbonate','Monomer / residual species','Residual release + polymer hydrolysis',C['orange']),('Reactive flame retardant','Covalently incorporated','Residual fraction + breakdown products',C['olive'])]
for i,(title,line1,line2,color) in enumerate(texts):
 yy=.78-i*.32
 ax[1].add_patch(FancyBboxPatch((.025,yy-.10),.95,.22,boxstyle='round,pad=.015',facecolor='white',edgecolor=color,linewidth=1.1,transform=ax[1].transAxes))
 ax[1].text(.055,yy+.065,title,color=color,fontsize=8.1,transform=ax[1].transAxes)
 ax[1].text(.055,yy-.005,line1,fontsize=7.5,transform=ax[1].transAxes)
 ax[1].text(.055,yy-.065,line2,fontsize=7.3,transform=ax[1].transAxes)
save(fig,'01-chemistry');rows('molecular_mass.csv',['chemical','formula','molar_mass_g_per_mol'],chem)

# 2. Slab diffusion: common Fo definition and distinct limiting approximations.
fig,ax=pair();fo=np.logspace(-4,1,250);f=released(fo);early=2/np.sqrt(np.pi)*np.sqrt(fo)
ax[0].semilogx(fo,f,color=C['blue'],label='Exact slab solution')
ax[0].semilogx(fo[fo<=.1],early[fo<=.1],'--',color=C['orange'],label='Early-time approximation')
ax[0].axhline(.5,color='.55',ls=':',lw=.8);ax[0].set_xlabel('Fourier number, Fo = Dt / L$^2$');ax[0].set_ylabel(r'Released fraction, $M_t/M_\infty$');ax[0].set_ylim(0,1.03);ax[0].legend(loc='lower right',frameon=False);panel(ax[0],'a','Exact release and limiting form')
t=np.linspace(0,30,241);L=.00025
records=[]
for D,color in zip([1e-16,1e-15,1e-14],COL):
 frac=released(D*t*86400/L**2);ax[1].plot(t,frac,color=color,label=f'D = {D:.0e} m$^2$ s$^{{-1}}$')
 records.extend(zip(np.full_like(t,D),t,frac))
ax[1].set_xlabel('Contact time (days)');ax[1].set_ylabel('Released fraction');ax[1].set_ylim(0,1.03);ax[1].legend(loc='upper left',frameon=False);panel(ax[1],'b','Illustrative D sensitivity; 2L = 0.5 mm')
save(fig,'02-diffusion');rows('diffusion_scenarios.csv',['D_m2_s','time_day','released_fraction'],records)

# 3. Temperature acceleration and coupled material geometry, not confidence intervals.
fig,ax=pair();R=8.314;T=np.linspace(5,80,151);T0=298.15;D0=1e-15
for E,c in zip([40000,60000,80000],COL):
 rat=np.exp(-E/R*(1/(T+273.15)-1/T0));ax[0].semilogy(T,rat,color=c,label=f'$E_a$ = {E/1000:.0f} kJ mol$^{{-1}}$')
ax[0].axhline(1,color='.5',ls=':',lw=.8);ax[0].axvline(25,color='.5',ls=':',lw=.8);ax[0].set_xlabel(r'Temperature ($^\circ$C)');ax[0].set_ylabel(r'$D(T)/D(25\,^\circ C)$');ax[0].legend(frameon=False,loc='upper left');panel(ax[0],'a','Arrhenius acceleration (scenario)')
TT=np.linspace(5,80,81);th=np.linspace(.1,2,76);DD=D0*np.exp(-60000/R*(1/(TT+273.15)-1/T0));F=released(DD[None,:]*86400/(th[:,None]*1e-3/2)**2)
im=ax[1].pcolormesh(TT,th,F,cmap='cividis',vmin=0,vmax=1,shading='auto',rasterized=True)
ct=ax[1].contour(TT,th,F,levels=[.1,.5,.9],colors='white',linewidths=.6);ax[1].clabel(ct,fmt='%.1f',fontsize=7)
ax[1].set_xlabel(r'Temperature ($^\circ$C)');ax[1].set_ylabel('Full thickness, 2L (mm)');panel(ax[1],'b','24-h release: temperature × thickness')
fig.colorbar(im,ax=ax[1],label='Released fraction',pad=.03,fraction=.046)
save(fig,'03-temperature');np.savez(DATA/'temperature_grid.npz',temperature_C=TT,thickness_mm=th,released_fraction=F)

# 4. Equilibrium partition / geometry; no kinetics inferred from equilibrium values.
fig,ax=pair();ratio=np.logspace(-2,3,200)
for K,c in zip([1,10,100,1000],COL):
 frac=ratio/(K+ratio);ax[0].semilogx(ratio,frac,color=c,label=f'$K_{{pf}}$ = {K}')
ax[0].set_xlabel('Receiver / polymer volume, $V_f/V_p$');ax[0].set_ylabel('Equilibrium receiver fraction');ax[0].legend(frameon=False,loc='upper left');ax[0].set_ylim(0,1.03);panel(ax[0],'a','Finite-volume partition ceiling')
ks=np.array([1,10,100,1000]);ff=10/(ks+10);mass=100*ff
ax[1].bar(np.arange(4),mass,color=COL[:4],width=.65);ax[1].set_xticks(np.arange(4),[str(x) for x in ks]);ax[1].set_xlabel('Partition coefficient, $K_{pf}$');ax[1].set_ylabel('Receiver mass at equilibrium (mg)');ax[1].set_ylim(0,112)
for i,v in enumerate(mass):ax[1].text(i,v+2,f'{v:.2f}',ha='center',fontsize=8)
ax[1].text(.98,.98,'Initial mass: 100 mg\n$V_f/V_p$: 10\nClosed system; no reaction',ha='right',va='top',transform=ax[1].transAxes,fontsize=7.5);panel(ax[1],'b','Identical loading, different availability')
save(fig,'04-partition');rows('partition_scenarios.csv',['K_pf','Vf_over_Vp','initial_mass_mg','receiver_mass_mg'],[(int(k),10,100,float(m)) for k,m in zip(ks,mass)])

# 5. Exposure accounting, illustrative concentrations and intake factors.
fig,ax=pair();pathways=['Food','Water','Dust','Air'];cf=.02;cw=.002;cd=1;ca=.01 # mg/kg, mg/L, mg/kg, microgram/m3
adult=np.array([cf*1*1000/60,cw*2*1000/60,cd*2e-5*1000/60,ca*15/60]);child=np.array([cf*.5*1000/15,cw*1*1000/15,cd*1e-4*1000/15,ca*8/15])
y=np.arange(4)
ax[0].scatter(adult,y-.12,s=30,color=C['blue'],marker='o',label='Adult: 60 kg',zorder=3);ax[0].scatter(child,y+.12,s=30,color=C['orange'],marker='D',label='Child: 15 kg',zorder=3);ax[0].set_yticks(y,pathways);ax[0].invert_yaxis();ax[0].set_xscale('log');ax[0].set_xlabel(r'Intake ($\mu$g kg$^{-1}$ day$^{-1}$)');ax[0].legend(frameon=False,loc='lower right');panel(ax[0],'a','Body-mass normalized intake (scenario)')
Cs=np.logspace(-2,3,150)
for BW,IR,c,label in [(60,2e-5,C['blue'],'Adult dust: 20 mg/day'),(15,1e-4,C['orange'],'Child dust: 100 mg/day')]:
 ax[1].loglog(Cs,Cs*IR*1000/BW,color=c,label=label)
ax[1].set_xlabel('Dust concentration (mg kg$^{-1}$)');ax[1].set_ylabel(r'Dust intake ($\mu$g kg$^{-1}$ day$^{-1}$)');ax[1].legend(frameon=False,loc='upper left');panel(ax[1],'b','Dust loading can change pathway ranking')
save(fig,'05-exposure');rows('exposure_scenarios.csv',['pathway','adult_ug_kg_day','child_ug_kg_day'],zip(pathways,adult,child))

# 6. Historical empirical data: Geyer 2017, no interpolation of production history.
fig,ax=pair();ax[0].bar([0,1],[2,380],color=[C['gray'],C['blue']],width=.6);ax[0].set_xticks([0,1],['1950','2015']);ax[0].set_ylabel('Resin + fiber production (Mt yr$^{-1}$)');ax[0].set_ylim(0,450)
for x,v in enumerate([2,380]):ax[0].text(x,v+8,str(v),ha='center')
panel(ax[0],'a','Historical production endpoints')
fates=['Recycled','Incinerated','Landfill / environment'];shares=np.array([9,12,79]);ax[1].barh(np.arange(3),shares,color=[C['olive'],C['orange'],C['blue']],height=.6);ax[1].set_yticks(np.arange(3),['Recycled','Incinerated','Landfill /\nenvironment']);ax[1].invert_yaxis();ax[1].set_xlim(0,100);ax[1].set_xlabel('Share of cumulative waste (%)')
for i,v in enumerate(shares):ax[1].text(v+1,i,f'{v}%',va='center')
ax[1].text(.99,.92,'Cumulative waste: 6,300 Mt',transform=ax[1].transAxes,ha='right',fontsize=7);panel(ax[1],'b','Global plastic waste fate through 2015')
save(fig,'06-lifecycle');rows('geyer2017_historical.csv',['measure','year_or_scope','value','unit','doi'],[['annual_production',1950,2,'Mt/yr','10.1126/sciadv.1700782'],['annual_production',2015,380,'Mt/yr','10.1126/sciadv.1700782'],['cumulative_waste','through2015',6300,'Mt','10.1126/sciadv.1700782'],*[[x,'through2015',int(v),'%','10.1126/sciadv.1700782'] for x,v in zip(fates,shares)]])

# 7. Mixture arithmetic and recycling recurrence: purely mathematical scenarios.
fig,ax=pair();hq=np.array([.15,.20,.25]);ax[0].bar(np.arange(4),[.15,.2,.25,.6],color=[*COL[:3],C['gray']],width=.6);ax[0].axhline(1,color='.35',ls='--',lw=.9,label='Screening reference = 1');ax[0].set_xticks(range(4),['HQ$_1$','HQ$_2$','HQ$_3$','HI']);ax[0].set_ylim(0,1.15);ax[0].set_ylabel('Dimensionless screening ratio')
for i,v in enumerate([.15,.2,.25,.6]):ax[0].text(i,v+.025,f'{v:.2f}',ha='center',fontsize=8)
ax[0].text(.04,.80,'Common endpoint and\ncompatible benchmarks assumed',transform=ax[0].transAxes,va='top',fontsize=7.3);panel(ax[0],'a','Concentration addition: illustrative sum')
n=np.arange(11)
for r,c in zip([.3,.7,.9],COL):
 q=r*.9;conc=[0]
 for _ in n[1:]:conc.append(q*conc[-1]+.10)
 ax[1].plot(n,conc,marker='o',ms=3,color=c,label=f'Recycled fraction r = {r:.1f}')
ax[1].set_xlabel('Recycling loop');ax[1].set_ylabel('Normalized carry-over concentration');ax[1].legend(frameon=False,loc='upper left');ax[1].text(.99,.03,'Survival s = 0.90; input a = 0.10\n$C_n = rsC_{n-1} + a$; $C_0 = 0$',ha='right',transform=ax[1].transAxes,fontsize=7);panel(ax[1],'b','Recurrence with repeated contamination')
save(fig,'07-mixture-recycling')

# 8. Evidence chain & decision workflow: conceptual figure, no numerical scoring.
fig,ax=pair()
for a in ax:a.axis('off')
panel(ax[0],'a','From identification to causal inference');panel(ax[1],'b','Control points across a product lifetime')
left=[('Chemical identification','Targeted + suspect + non-target LC/GC-MS'),('External / internal exposure','Migration tests + food/dust + biomarkers'),('Mechanistic hazard','Receptors + metabolism + organ endpoints'),('Human / ecological risk','Time, dose, confounding and vulnerability')]
right=[('Design','Inventory; functional alternatives; grouping'),('Use','Temperature / time / food-type compatibility'),('Recycling','Sort; trace; remove legacy contaminants'),('Verification','Chemical analytics + bioassays + follow-up')]
for a,items in zip(ax,[left,right]):
 for i,(title,body) in enumerate(items):
  y=.84-i*.24
  a.add_patch(FancyBboxPatch((.025,y-.06),.95,.16,boxstyle='round,pad=.015',facecolor='white',edgecolor=COL[i%4],linewidth=1,transform=a.transAxes))
  a.text(.06,y+.045,title,color=COL[i%4],transform=a.transAxes,fontsize=8.4)
  a.text(.06,y-.02,body,transform=a.transAxes,fontsize=6.7)
  if i<3:a.add_patch(FancyArrowPatch((.5,y-.077),(.5,y-.124),arrowstyle='-|>',mutation_scale=9,color='.4',transform=a.transAxes))
save(fig,'08-evidence')

# 9. Empirical immune endpoint, redrawn from EFSA 2023 Appendix F, Table F.1.
# The two zero-dose controls remain separate; SD is not SE or a confidence interval.
fig,ax=pair()
with (DATA/'efsa2023_table_F1.csv').open() as f:
    immune=list(csv.DictReader(f))
for a,sex,label in zip(ax,['female','male'],['a','b']):
    for pnd,offset,c,marker in [(21,-.065,C['blue'],'o'),(42,.065,C['orange'],'s')]:
        rr=[r for r in immune if r['sex']==sex and int(r['PND'])==pnd]
        means=[float(r['Th17_mean_percent']) for r in rr]
        sd=[float(r['SD_percent']) for r in rr]
        a.errorbar(np.arange(5)+offset,means,yerr=sd,fmt=marker,color=c,ms=4,capsize=2.4,elinewidth=1,label=f'PND {pnd}',zorder=3)
    a.set_xticks(np.arange(5),['0 (C1)','0 (C2)','0.475','4.75','47.5'])
    a.set_xlabel(r'Maternal BPA dose group ($\mu$g kg$^{-1}$ day$^{-1}$)')
    a.set_ylabel('Offspring spleen Th17 cells (%)')
    a.set_ylim(0,4.3);a.set_yticks([0,1,2,3,4]);a.legend(frameon=False,loc='upper left')
    a.text(.53,.96,'Mean ± SD\nn = 10; highest dose n = 11',ha='center',va='top',transform=a.transAxes,fontsize=7)
    panel(a,label,sex.capitalize()+' offspring: EFSA Table F.1')
save(fig,'08-immune')

Fo50=brentq(lambda x:float(released(x))-.5,.001,1)
out={'model_type':'illustrative; not fitted to experimental observations','slab_half_thickness_m':.00025,'D_ref_m2_s':1e-15,'T_ref_K':298.15,'Ea_J_mol':60000,'Fo_at_half_release':Fo50,'t50_days_D1e_15':Fo50*.00025**2/1e-15/86400,'released_24h_ref':float(released(1e-15*86400/.00025**2)),'released_30d_ref':float(released(1e-15*30*86400/.00025**2)),'D_ratio_60C_Ea60kJ':float(np.exp(-60000/8.314*(1/333.15-1/298.15))),'adult_total_ug_kg_day':float(adult.sum()),'child_total_ug_kg_day':float(child.sum())}
(DATA/'model_summary.json').write_text(json.dumps(out,indent=2))
print(json.dumps(out,indent=2))
print('Exported 9 paired figures (8 used in paper, 16 panels) in vector PDF and 350-dpi PNG.')
